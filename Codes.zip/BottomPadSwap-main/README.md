# BottomPadSwap
Introducing BottomPadSwap - a new aroma plugin for half-broken gamepads! Replace malfunctioning bottom buttons with custom combos for easy Home menu navigation and system shutdown. 

Note: Wiiu menu may experience occasional crashes. Powering on the gamepad using turn-off shortcut is not supported. 

Thanks to the Aroma Discord server and its members (Maschell, Nathaniel_s7, DaThinkingChair, Quarky...)   for helping all along the process of creating this first plugin 

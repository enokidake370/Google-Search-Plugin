#pragma once

#include "version.h"

#define VERSION      "v1.1.0"
#define VERSION_FULL VERSION VERSION_EXTRA
